#!/bin/bash

function export_variables {
    local util_dir=~/qmk_utils
    local download_dir=$util_dir/wsl_downloaded
}

export_variables
